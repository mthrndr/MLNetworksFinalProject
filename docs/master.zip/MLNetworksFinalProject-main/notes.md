Main idea is that the network nodes are represented in a table, each row is a
single node being considered, and each column represents the node it can reach.
The value is the cost to reach that node, with 0 either meaning it cannot be
reached, or that it is trying to reach itself.
