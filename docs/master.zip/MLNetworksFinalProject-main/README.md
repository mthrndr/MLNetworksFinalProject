# MLNetworksFinalProject
Final Project for ELEN6772 - Machine Learning for Networks

NOTE: Requires Python 3.11+

Run 'make dev_env' to install dependencies.
Make Sure PYTHONPATH is set.

main.py implements a generic q-routing protocol.
node.py contains the Node class and it's associated methods and functions.
