def test_initialize_sim():
    assert True
